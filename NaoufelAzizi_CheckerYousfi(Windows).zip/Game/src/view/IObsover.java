package view;

public interface IObsover {
    
    void update();

}

package poussin;

public class States {
        public static String path = "./src/view/icons/";
        public static String[] states = { "Normal",
                        "Bombeur",
                        "Bloqueur",
                        "Charpentier",
                        "Foureur",
                        "Grimpeur",
                        "Parachutist",
                        "Tunnelier" };

        public static String[] icons = { "normal.jpg",
                        "bomb.jpg",
                        "block.jpg",
                        "charp.jpg",
                        "foreur.jpg",
                        "grimpeur.jpg",
                        "parach.jpg",
                        "tunnelier.jpg" };
        public static String[] keys = { "N", "B", "L", "M", "Y", "G", "P", "T" };

}

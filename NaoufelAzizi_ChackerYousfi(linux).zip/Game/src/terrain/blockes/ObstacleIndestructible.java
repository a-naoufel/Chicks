package terrain.blockes;
public interface ObstacleIndestructible {
}
